<?php
/*
Plugin Name: WordPressPete Converter
Plugin URI: https://wordpresspete.com
Description: Quickly and easily export your WordPress installation to WordPressPete format. Integrate Laravel, migrate, launch, or clone WordPress sites in minutes. WordPressPete is a local and production server environment that can be installed in macOS and Linux with just one command from the terminal.
Version: 1.0
Author: Ozone Group
Author URI: https://ozonegroup.co
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

require_once(ABSPATH . 'wp-admin/includes/file.php');
require_once( ABSPATH. '/wp-config.php');


if ( ! function_exists('write_log')) {
   function write_log ( $log )  {
      if ( is_array( $log ) || is_object( $log ) ) {
         error_log( print_r( $log, true ) );
      } else {
         error_log( $log );
      }
   }
}

if ( ! function_exists('get_table_prefix')) {
function get_table_prefix() {
       global $wpdb;
       return $wpdb->prefix;
}
}


function isEnabled($func) {
    return is_callable($func) && false === stripos(ini_get('disable_functions'), $func);
}


if ( ! function_exists('formatSizeUnits')) {
function formatSizeUnits($bytes)
    {
        if ($bytes >= 1073741824)
        {
            $bytes = number_format($bytes / 1073741824, 2) . ' GB';
        }
        elseif ($bytes >= 1048576)
        {
            $bytes = number_format($bytes / 1048576, 2) . ' MB';
        }
        elseif ($bytes >= 1024)
        {
            $bytes = number_format($bytes / 1024, 2) . ' KB';
        }
        elseif ($bytes > 1)
        {
            $bytes = $bytes . ' bytes';
        }
        elseif ($bytes == 1)
        {
            $bytes = $bytes . ' byte';
        }
        else
        {
            $bytes = '0 bytes';
        }

        return $bytes;
}
}

function create_posttype() {
register_post_type( 'news',
// CPT Options
 
array(
  'labels' => array(
   'name' => __( 'news' ),
   'singular_name' => __( 'News' )
  ),
  'public' => true,
  'has_archive' => false,
  'rewrite' => array('slug' => 'news'),
 )
);
}
// Hooking up our function to theme setup
add_action( 'init', 'create_posttype' );
 
/* Custom Post Type End */

// INSTALL DB TABLES FOR PETE
global $pete_db_version;
$pete_db_version = '1.0';

function pete_install() {
   	global $wpdb;
   	global $pete_db_version;

   	$table_name = $wpdb->prefix . 'pete_files';
	
   	$charset_collate = $wpdb->get_charset_collate();

   	$sql = "CREATE TABLE $table_name (
   		id mediumint(9) NOT NULL AUTO_INCREMENT,
   		created_at datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
   		file_name varchar(77) DEFAULT '' NOT NULL,
   		PRIMARY KEY  (id)
   	) $charset_collate;";

   	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
   	dbDelta( $sql );

   	add_option( 'pete_db_version', $pete_db_version );
}

register_activation_hook( __FILE__, 'pete_install' );


function theme_options_panel(){
  add_menu_page('Theme page title', 'Pete Converter', 'manage_options', 'pete-export-options', 'testview',plugins_url('pete-converter/petefaceicon.png', dirname(__FILE__) ),6 );
  //add_submenu_page( 'theme-options', 'Settings page title', 'Settings menu label', 'manage_options', 'theme-op-settings', 'wps_theme_func_settings');
  //add_submenu_page( 'theme-options', 'FAQ page title', 'FAQ menu label', 'manage_options', 'theme-op-faq', 'wps_theme_func_faq');
}
add_action('admin_menu', 'theme_options_panel');
function wps_theme_func(){ echo '<div class="wrap"><div id="icon-options-general" class="icon32"><br></div> <h2>Theme</h2></div>'; } 
//function wps_theme_func_settings(){ echo '<div class="wrap"><div id="icon-options-general" class="icon32"><br></div> <h2>Settings</h2></div>'; } 
//function wps_theme_func_faq(){ echo '<div class="wrap"><div id="icon-options-general" class="icon32"><br></div> <h2>FAQ</h2></div>'; }


function testview() { ?>

	<div class="wrap"><h1>Export this WordPress to WordPressPete</h1>
	
	<p>Note: Currently the Pete Converter only works in UNIX-based systems like macOS or Linux.</p>
	
	
	<?php
	if (isEnabled('shell_exec')) {
	    echo '<form action="'.admin_url('/admin.php?page=pete-export-options').'" method="post">';
	}else{
		echo '<form action="'.admin_url('/admin.php?page=pete-export-options').'" style="display: none;" method="post">';
	}
	?>
		
		<?php
			if(isset($_GET['console_output'])){
				echo '<p><i>'.$_GET['console_output'].'</i></p>';
			}
		?>
		
		<p><input type="checkbox" name="mysql_sw" id="mysql_sw" value="mysql_route_active"> Tick this box to if you are running this WordPress on MAMP or with another isolated version of MySQL (<i>The default mysqldump route is for MAMP</i>)</p>
				
		<p><input type="text" name="mysqldump_field" id="mysqldump_field" style="display: none; padding: 10px 10px;font-size: 1em;line-height: 100%;height: 1.7em;width: 100%;outline: 0;background-color: #fff;" value="/Applications/MAMP/Library/bin/mysqldump"></p>
	
	<input class='button-primary' type='submit' name="pete-converter" id="pete-converter" value='Convert to Pete'>
	<?php wp_nonce_field('export_with_bash','pete_nonce_field'); ?>
	</form>
	
	</div>
	
	
	<script>
		
		jQuery( "#mysql_sw" ).click(function() {
		  	jQuery('#mysqldump_field').toggle();
		});
	
	</script>
	
	<?php
	if (!isEnabled('shell_exec')) {
		echo '<p><b>You must activate the shell_exec function in your php.ini config file to run the this plugin.</b></p>';
	}
    ?>
	
<?php
	global $wpdb;
	$pete_files = $wpdb->get_results( "SELECT * FROM ".$wpdb->prefix."pete_files Order By created_at DESC" );
	$pete_file_route = wp_upload_dir();
	$pete_file_route = $pete_file_route['basedir'];
	$pete_file_route =  $pete_file_route. "/". "pete-converter" ."/";
?>
	

	
	<div class="wrap">
		
		<?php
		
		$download_dir = wp_upload_dir();
		$download_dir = $download_dir['baseurl'];
		
	
				
		?>
		<br />
		<?php if(isset($pete_files[0])){
			echo '<table class="widefat fixed" cellspacing="0">';
		}else{
			echo '<table class="widefat fixed" hidden="true" cellspacing="0">';
		}
		
		?>
	
	    <thead>
	    <tr>

	            <th id="columnname" class="manage-column column-columnname" style="width:40%" scope="col">File</th> 
	            <th id="columnname" class="manage-column column-columnname" style="width:20%" scope="col">Created at</th>
	            <th id="columnname" class="manage-column column-columnname" style="width:20%" scope="col">Size</th>
				<th id="columnname" class="manage-column column-columnname" style="width:20%" scope="col">Options</th>
	    </tr>
	    </thead>
		
	    <tfoot>
	    <tr>

	            <th class="manage-column column-columnname" scope="col">File</th>
	            <th class="manage-column column-columnname" scope="col">Date</th>
	            <th class="manage-column column-columnname" scope="col">Size</th>
				<th class="manage-column column-columnname" scope="col">Options</th>
	    </tr>
	    </tfoot>
	 <tbody>
	<?php $i=1;?>
	 <?php foreach ($pete_files as $pete_file): ?>
		 
		 
		 <?php
	
		 if($i % 2 == 0){
			 echo '<tr class="alternate">';
		 }else{
			 echo '<tr>';
		 }
		 
		 ?>
		 
		 	 	
		 <td class="column-columnname"><?php echo $pete_file->file_name; ?></td>
		 <td class="column-columnname">
		
			 <?php echo $pete_file->created_at?> UTC
		
		 </td>
		 <td class="column-columnname"><?php echo formatSizeUnits(filesize($pete_file_route.$pete_file->file_name)); ?></td>
		 <td class="column-columnname">
			 
			<a class="button activate-now" style="display: inline-block" href="<?php echo $download_dir.'/'.'pete-converter'.'/'.$pete_file->file_name?>">Download</a>  
			<form action="<?php echo admin_url( '/admin.php?page=pete-export-options'); ?>" style="display: inline-block" method="post">
			  
			  <?php wp_nonce_field('delete_pete_file','pete_nonce_field'); ?>
			  <input type="hidden" id="delete_pete_file" name="delete_pete_file" value="<?php echo $pete_file->file_name?>">
			  <input type="hidden" id="delete_pete_file_id" name="delete_pete_file_id" value="<?php echo $pete_file->id?>">
			  
			  <input type="submit" class="button button-delete" style="display: inline-block;" value="Delete" />
			  
	
			  
			</form>
		</td>
	 </tr>
	<?php $i++;?>
	<?php endforeach; ?>
	</tbody>
	</table>
	
	</div>
	

<?php }

function my_header_scripts(){
  ?>
  <script>alert( 'Hi Pete!' ); </script>
  <?php
}


function go_to_file(){
	
	write_log("entro en go_to_file");
	
	$filename = $_GET['download_pete_file'];
	$download_dir = wp_upload_dir();
	$download_dir = $download_dir['baseurl'];
	$file_url = $download_dir.'/'.'pete-converter'.'/'.$filename;
	
    ?>
    <script>window.location.assign('<?php echo $file_url?>')</script>
    <?php
	
}


class ThePeteClass{
	
	
	
    function __construct(){ 
		global $wpdb;
		
		if(isset($_GET['download_pete_file'])){
					
			add_action( 'admin_footer', 'go_to_file' );	
	    }	
		
		
			if(isset($_POST['delete_pete_file'])) { 
			
				if ( !empty($_POST['delete_pete_file']) && check_admin_referer( 'delete_pete_file', 'pete_nonce_field' )){
			
					$pete_file_route = wp_upload_dir();
					$pete_file_route = $pete_file_route['basedir'];
					$pete_file_route =  $pete_file_route. "/". "pete-converter" ."/".$_POST['delete_pete_file'];
					write_log("Entro en: delete_pete_file: ".$pete_file_route);
				
					unlink($pete_file_route);
					
					$table_name = $wpdb->prefix . 'pete_files';
					$delete_pete_file_id = $_POST['delete_pete_file_id'];
					$wpdb->delete( $table_name , array( 'id' => $delete_pete_file_id ) );
					
			
				}
			
			
			}	
		
		if(isset($_POST['pete-converter'])) { 
			
		    if ( !empty($_POST['pete-converter']) && check_admin_referer('export_with_bash', 'pete_nonce_field' ) && ( current_user_can( 'manage_options' ))){
				
				write_log("entro en pete-converter");
				
				if(isset($_POST['mysql_sw'])){
					//write_log("entro en mysqlsw");
					
					if($_POST['mysql_sw']=="mysql_route_active"){
						$mysqldump_route = $_POST['mysqldump_field'];
						//write_log("mysqldump: $mysqldump_route");
					}
					
				}else{
					$mysqldump_route = "mysqldump";
					//write_log("mysqldump: $mysqldump_route");
					
				}
				
				$site_url = site_url();
				$app_root = get_home_path();
				$site_url = str_replace("http://","",$site_url);
				$site_url = str_replace("https://","",$site_url);
				$prefix = get_table_prefix();
				
				$route_array = explode("/", $app_root);
				//write_log($route_array);
				$project_name = array_pop($route_array);
				$project_name = array_pop($route_array);
				//write_log($project_name);
				$route = str_replace($project_name,"",$app_root);
				$route = substr($route, 0, -1);
				
				$upload_dir = wp_upload_dir();
				$upload_dir = $upload_dir['basedir'];
				
				if (!file_exists("$upload_dir/pete-converter")) {
				    mkdir("$upload_dir/pete-converter", 0777, true);
				}
				$upload_dir = $upload_dir . '/pete-converter';
				
				$key = md5(uniqid(rand(), true));
				
				//$command = plugin_dir_path( __DIR__ )."/pete-converter"."./export_to_pete.sh -r {$route} -u {$site_url} -m {$mysqldump_route} -p {$prefix} -n {$project_name} -d {$upload_dir} -k {$key}";
				
				$command = "sh ".plugin_dir_path( __DIR__ )."pete-converter/export_to_pete.sh -r {$route} -u {$site_url} -m {$mysqldump_route} -p {$prefix} -n {$project_name} -d {$upload_dir} -k {$key}";
				
				write_log($command);
				$output = "";
				
				#chdir(plugin_dir_path( __DIR__ )."/pete-converter"."/");
				
				$output = shell_exec($command);		
				write_log("output aca");
				write_log($output);
				
				//Insert in table
				global $wpdb;
				$table_name = $wpdb->prefix . 'pete_files';
				$file_name = $project_name.$key.".zip";
				$wpdb->insert( 
						$table_name, 
						array( 
							'created_at' => current_time( 'mysql' ), 
							'file_name' => $file_name, 
						) 
					);
				/*	
				if($output != ""){
					wp_redirect("/wp-admin/admin.php?page=pete-export-options&console_output=$output");
				}else{
					wp_redirect("/wp-admin/admin.php?page=pete-export-options");
				}*/
				wp_redirect("/wp-admin/admin.php?page=pete-export-options&download_pete_file=$file_name");
				
		    }else{
		        wp_die('Security check fail'); 
		    }
		}
    }
}

add_action('plugins_loaded','newobj');

function newobj(){
    $the_pete_class = new ThePeteClass;
}










?>
