<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */



define('WP_HOME','http://template.petelocal.net');
define('WP_SITEURL','http://template.petelocal.net');
define('DB_NAME', 'db_9b3357f1c61eb9a3499c7ce718838092');
define('DB_USER', 'u_ebef15e016e0a8cbabcfee94c17c7b');
define('DB_PASSWORD', '08de4c6c660f314a');
define('DB_HOST', 'db');

define('AUTH_KEY',         'Pfg1Brx9G1jrxdIvRkChAqhY10F9Wx6JB7ivoT8KVmYVWA0pKpipsdMAS9vVIA');
define('SECURE_AUTH_KEY',  'eSe1MNzYk9d1iXFNkzYjkgzPgOyYfb3LAon1xRyvCodhQqiKLd297wpbvAQacR');
define('LOGGED_IN_KEY',    '0J9eus8QRo0NeE0STzYqPeWF7XLpzTn6Rxasr7iNO9sBtjJsNA2ncuMsuQsvty');
define('NONCE_KEY',        'k8Z20evePg0OKZbMxpnpubT2xeukOXqrd3Y2qd3KPjfCXx2okgzJeiaMeTwgxV');
define('AUTH_SALT',        'r1m4zK1ElTykGYo41sQqJEDcF7fEis7h7Ea1nGCYZR1iyws8rGKnKADgEIRAe0');
define('SECURE_AUTH_SALT', 'w4mhFjjPwhKLonBUSTj2uVBgiJHAONnrv56g84YZHrLtB6c36rTvm8u9uJI30l');
define('LOGGED_IN_SALT',   'K7UpnZubVl4oERlV3bfLgcr0ywLZhMCz7yKUy2gcAcYUwspBSot1BYxGPaxPxS');
define('NONCE_SALT',       'Brpe5GPOhrdiB8sMzuQ6cvRY6Vf16nOyFRyQpzhNATrsnzZehufCL939HP7IgQ');

define('COOKIE_DOMAIN', '.template.petelocal.net' );



/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';
define('WP_MEMORY_LIMIT', '256M');
/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

