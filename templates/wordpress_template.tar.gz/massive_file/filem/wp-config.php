<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */



define('WP_HOME','http://colombia1.petelocal.net');
define('WP_SITEURL','http://colombia1.petelocal.net');
define('DB_NAME', 'db_af000f423390b4116dee683fda667548');
define('DB_USER', 'u_16f4d14671748de9c0a4e3442ab448');
define('DB_PASSWORD', '7c4e038911451b40');
define('DB_HOST', 'db');
   	
define('AUTH_KEY',         'rb069PatFdbnVqd3e4mvadViFRXYthYXvKZngeLjnroqDrKpqiGuj9k4f6ws4F');
define('SECURE_AUTH_KEY',  '33jbjF3AZe41oa37eGwShPjJwKPmICwqDvxC9ZWHFu0mBPNxLtIxONKDHxi9fv');
define('LOGGED_IN_KEY',    'NMt1UfFCBUZWbpZ48LPLwJNEvL2vHJgu6t4E2HluhtC6gXWnORKSAa3L0AtI2x');
define('NONCE_KEY',        'DdM9jwn7FyKxsCceUsf1BYKJTstZmbnyptz5tIUL3trHcqEjI3athTOdM4575E');
define('AUTH_SALT',        'OBEnyE6PLbbaGiEHoIPnSPmp5sTTQrfIYyW9SkcIYxwtOHcEZMAFWECgsqZDBp');
define('SECURE_AUTH_SALT', 'ANDVAqfs75cvJLy5Au8k3SKFbn7SEry3YOCEag3ql00obOFcs0aZ5i4qA1lmhk');
define('LOGGED_IN_SALT',   'AjYX65FFJgsa6KqPDog6TBNFRlD8uKZhzUuiWI49Kzju7LZPwfLibErWUZf1VZ');
define('NONCE_SALT',       'COMG2ntMiBuB40b8v5hJ6DoR4eJivWDpfmxgDQ30HIv1wqdpqTAVWXTAPfXZcx');

define('COOKIE_DOMAIN', '.colombia1.petelocal.net' );



/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';
define('WP_MEMORY_LIMIT', '256M');
/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

